#include<iostream>
#include<cstring>
#include<cmath>
using namespace std;

int main()
{
  char name[80], origin_destination[80], Tcategory, category, Ttype;
  int price;
  float discount, net_price;
  string flightNum, seatNum;
  
  
    cout<<"\nFLIGHT RESERVATION MANAGEMENT SYSTEM";
    cout<<"\n-------------------------------------";
    cout<<"\nFLIGHT NO.       ORIGIN - DESTINATION                  BOARD. DATE           BOARD. TIME          PRICE (RM)";
    cout<<"\n----------       -------------------------------       -----------           -----------          ----------";
    cout<<"\nMH001            KUALA LUMPUR - KUALA TERENGGANU        13/2/2014               11:35             [E]200.00/ [B]400.00";
    cout<<"\nMH002            KUALA TERENGGANU - KUALA LUMPUR        16/2/2014               13:45             [E]200.00/ [B]400.00";
    cout<<"\nMH003            KUALA LUMPUR - KOTA KINABALU           15/2/2014                6:00             [E]600.00/ [B]1200.00";
    cout<<"\nMH004            KOTA KINABALU - KUALA LUMPUR           20/2/2014               18:00             [E]600.00/ [B]1200.00";
    cout<<"\nMH005            KUALA LUMPUR - KUCHING                 29/3/2014               14:00             [E]450.00/ [B]900.00";
    cout<<"\nMH006            KUCHING - KUALA LUMPUR                 3/4/2014                12:00             [E]450.00/ [B]900.00";
    
    cout<<"\n\nEnter passenger's information";
    cout<<"\n-->Enter your name: ";
    cin.getline(name,80);
    cout<<"-->Enter your flight number: ";
    cin>>flightNum ;
    cout<<"-->Enter your ticket type [E]Economy / [B]Business: ";
    cin>>Tcategory;
    cout<<"-->Enter your trip [1]One-way trip / [2]Return trip: ";
    cin>>Ttype;
  
  if(Tcategory=='B' || Tcategory=='b')
    {
      cout<<"-->Choose your seat number (A1/A2/A3/A4/B1/B2/B3/B4/C1/C2/C3/C4/D1/D2/D3/D4): ";
      cin>>seatNum;
    }
    else if(Tcategory=='E' || Tcategory=='e')
    {
      cout<<"-->Enter your seat number: "<<"Free seating";
    }
    
    cout<<"-->Enter your category [I]Infant / [A]Adult / [S]Senior / [D]Disable: ";
    cin>>category;
    
    cout<<"\nCustomer's Information";
    cout<<"\n-->Name                 : "<<name;
    cout<<"\n-->Flight Number        : "<<flightNum;
    cout<<"\n-->Seat                 : "<<seatNum;
    cout<<"\n-->Category             : "<<category;

   
    cout<<" ";
    //origin-Destination
    if(Ttype ==1)
    {
      if(flightNum =="MH001")
      {
        cout<<"\n-->Origin-Destination   : "<<"KUALA LUMPUR <-> KUALA TERENGGANU";
        cout<<"\n-->Flight Number        : "<<"MH001";
      }
      else if(flightNum =="MH002")
      {
        cout<<"\n-->Origin-Destination   : "<<"KUALA TERENGGANU <-> KUALA LUMPUR";
        cout<<"\n-->Flight Number        : "<<"MH002";
      }
      else if(flightNum =="MH003")
      {
        cout<<"\n-->Origin-Destination   : "<<"KUALA LUMPUR <-> KOTA KINABALU";
        cout<<"\n-->Flight Number        : "<<"MH003";
      }
      else if(flightNum =="MH004")
      {
        cout<<"\n-->Origin-Destination   : "<<"KOTA KINABALU <-> KUALA LUMPUR";
        cout<<"\n-->Flight Number        : "<<"MH004";
      }
      else if(flightNum =="MH005")
      {
        cout<<"\n-->Origin-Destination    : "<<"KUALA LUMPUR <-> KUCHING";
        cout<<"\n-->Flight No             : "<<"MH005";
      }
      else if(flightNum =="MH006")
      {
        cout<<"\n-->Origin-Destination    : "<<"KUCHING <-> KUALA LUMPUR";
        cout<<"\n-->Flight Number         : "<<"MH006";
      }
    }
    else if(Ttype>=2)
    {
      if(flightNum =="MH001")
      {
        cout<<"\n-->Origin-Destination   : "<<"KUALA LUMPUR <-> KUALA TERENGGANU";
        cout<<"\n-->Flight Number        : "<<"MH001";
      }
      else if(flightNum =="MH002")
      {
        cout<<"\n-->Origin-Destination   : "<<"KUALA TERENGGANU <-> KUALA LUMPUR";
        cout<<"\n-->Flight Number        : "<<"MH002";
      }
      else if(flightNum =="MH003")
      {

        cout<<"\n-->Origin-Destination   : "<<"KUALA LUMPUR <-> KOTA KINABALU";
        cout<<"\n-->Flight Number        : "<<"MH003";
      }
      else if(flightNum =="MH004")
      {
        cout<<"\n-->Origin-Destination   : "<<"KOTA KINABALU <-> KUALA LUMPUR";
        cout<<"\n-->Flight Number        : "<<"MH004";
      }
      else if(flightNum =="MH005")
      {
        cout<<"\n-->Origin-Destination   : "<<"KUALA LUMPUR <-> KUCHING";
        cout<<"\n-->Flight Number        : "<<"MH005";
      }
      else if(flightNum =="MH006")
      {
        cout<<"\n-->Origin-Destination   : "<<"KUCHING <-> KUALA LUMPUR";
        cout<<"\n-->Flight No            : "<<"MH006";
      }
      if(flightNum =="MH001")
      {
        cout<<"\n-->Origin-Destination   : "<<"KUALA TERENGGANU <-> KUALA LUMPUR";
        cout<<"\n-->Flight Number        : "<<"MH002";
      }
      else if(flightNum =="MH003")
      {
        cout<<"\n-->Origin-Destination   : "<<"KOTA KINABALU <-> KUALA LUMPUR";
        cout<<"\n-->Flight Number        : "<<"MH004";
      }
      else if(flightNum =="MH005")
      {
        cout<<"\n-->Origin-Destination   : "<<"KUCHING <-> KUALA LUMPUR";
        cout<<"\n-->Flight Number        : "<<"MH006";
      }
      
    }
    if((flightNum =="MH001" || flightNum =="MH002") && Ttype =='1')
    {
      if(toupper(Tcategory)=='E')
      {
        price=200.00;
      }
      else if(toupper(Tcategory)=='B')
      {
        price=400.00;
      }
    }
    else if((flightNum =="MH003" || flightNum =="MH004") && Ttype =='1')
    {
      if(toupper(Tcategory)=='E')
      {
        price=600.00;
      }
      else if(toupper(Tcategory)=='B')
      {
        price=1200.00;
      }
    }
    else if((flightNum =="MH005" || flightNum =="MH006") && Ttype=='1')
    {
      if(toupper(Tcategory)=='E')
      {
        price=450.00;
      }
      else if(toupper(Tcategory)=='B')
      {
        price=900.00;
      }
    }
    else if((flightNum =="MH001" || flightNum =="MH002") && Ttype =='2')
    {
      if(toupper(Tcategory)=='E')
      {
        price=200.00*2;
      }
      else if(toupper(Tcategory)=='B')
      {
        price=400.00*2;
      }
    }
    else if((flightNum =="MH003" || flightNum =="MH004") && Ttype =='2')
    {
      if(toupper(Tcategory)=='E')
      {
        price=600.00*2;
      }
      else if(toupper(Tcategory)=='B')
      {
        price=1200.00*2;
      }
    }
    else if((flightNum =="MH005" || flightNum =="MH006") && Ttype =='2')
    {
      if(toupper(Tcategory)=='E')
      {
        price=450.00*2;
      }
      else if(toupper(Tcategory)=='B')
      {
        price=900.00*2;
      }
    }
    //category
    cout<<"\n-->Category: ";
    if(category=='I')
    {
      cout<<category<<" - Infant";
      discount=price*0.7;
      net_price=price-discount;
    }
    else if(category=='A')
    {
      cout<<category<<" - Adult";
      discount=price*0.00;
      net_price=price-discount;
    }
    else if(category=='S')
    {
      cout<<category<<" - Senior";
      discount=price*0.45;
      net_price=price-discount;
    }
    else if(category=='D')
    {
      cout<<category<<" - Disable";
      discount=price*0.6;
      net_price=price-discount;
    }
    cout<<"\n-->Price                : "<<"RM"<<price;
    cout<<"\n-->Discount             : "<<"RM"<<discount;
    cout<<"\n-->Net Price            : "<<"RM"<<net_price;
    
    return 0;
}
