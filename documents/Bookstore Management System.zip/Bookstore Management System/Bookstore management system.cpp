#include<iostream>
#include<cstring>
#include<cmath>
using namespace std;

double input();
double calcDiscount(double, char);
double calcTax();
double bookCondCalc(string, double);
void output(double, double, double, double, string);
void customerReceipt();

//Variable Declaration
string title[13], bookCond[13], bookGenre[13];
int bookID[13], custBookID;
double bookPrice[13], priceForTax;
char member;

int main()
{
	//Variable Declaration
	string name;
	double price, totalPrice = 0, discount = 0, condDiscount = 0, tax = 0;
	
	//List Of Product;
	//Product1;
	title[0] = "Harry Potter";
	bookID[0] = 0;
	bookPrice[0] = 20.00;
	bookCond[0] = "New";
	bookGenre[0] = "Fiction";
	
	//Product2;
 	title[1] = "The Star and I ";
 	bookID[1] = 1;
 	bookPrice[1] = 16.00;
 	bookCond[1] = "New";
 	bookGenre[1] = "Fiction";
 	
 	//Product3;
	title[2] = "The Last Thing He Told Me ";
	bookID[2] = 2;
	bookPrice[2] = 18.00;
	bookCond[2] = "Used";
	bookGenre[2] = "Fiction";
	
	//Product 4;
	title[3] = "Teguran Dari Langit";
	bookID[3] = 3;
	bookPrice[3] = 18.00;
	bookCond[3] = "New";
	bookGenre[3] = "Islamic";
	
	//product 5;
	title[4] = "C++";
	bookID[4] = 4;
	bookPrice[4] = 15.00;
	bookCond[4] = "New";
	bookGenre[4] = "Study";
	
	//product 6;
	title[5] = "Nasihat Buat Diri";
	bookID[5] = 5;
	bookPrice[5] = 16.90;
	bookCond[5] = "Used";
	bookGenre[5] = "Islamic";
	
	//product 7;
	title[6] = "The Love Hypothesis";
	bookID[6] = 6;
	bookPrice[6] = 15.00;
	bookCond[6] = "New";
	bookGenre[6] = "Fiction";
	
	//product 8;	
	title[7] = "The 1619 Project";
	bookID[7] = 7;
	bookPrice[7] = 18.00;
	bookCond[7] = "Used";
	bookGenre[7] = "Fiction";
	
	//product 9;
	title[8] = "Hellions (Marvel Comics)";
	bookID[8] = 8;
	bookPrice[8] = 18.00;
	bookCond[8] = "New";
	bookGenre[8] = "Fiction";
	
	//product 10;
	title[9] = "Mashle: Magic and Muscles";
	bookID[9] = 9;
	bookPrice[9] = 15.00;
	bookCond[9] = "New";
	bookGenre[9] = "Fiction";
	
	//product 11;
	title[10] = "JAVA Programming ";
	bookID[10] = 10;
	bookPrice[10] = 22.00;
	bookCond[10] = "New";
	bookGenre[10] = "Study";
	
	//product 12;
	title[11] = "Kapal Terakhir Di Dunia (Novel)";
	bookID[11] = 11;
	bookPrice[11] = 18.00;
	bookCond[11] = "New";
	bookGenre[11] = "Fiction";
	
	//product 13;
	title[12] = "How Asia Works (Magazine)";
	bookID[12] = 12;
	bookPrice[12] = 15.00;
	bookCond[12] = "New";
	bookGenre[12] = "Non Fiction";

	int repeatprogram = 1;
	
	while (repeatprogram == 1)
	{
	
		cout<<"\n\t---------------------------------------------------------------------------------------\n";
		cout<<"\t       W E L C O M E  T O  B O O K  S T O R E   M A N A G E M E N T  S Y S T E M    \n";
		cout<<"\t---------------------------------------------------------------------------------------\n";
	
	
		int j = 0;
		int i = 0;
	
		cout<<"\n\nPlease enter your name: ";
		cin>>name;
	
		cout<<"\nPlease enter '1' to proceed : ";
		cin>>j;
	
		if(j == 1)
		{
			char repeat = 'Y';
	
			while (repeat != 'N')
			{
				while(i != 13)
				{
					cout<<"\n";
					cout<<bookID[i];
					cout<<" : ";
					cout<<title[i];
			
					i++;
				}
		
				price = input();
				totalPrice = totalPrice + price;
			
				cout<<"\n\nDo you want to buy another book? (Y - yes / N - no) :";
				cin>>repeat;
			}
	
			cout<<"\nDo you have a member card? (Y - Yes / N - No) : ";
			cin>>member;
		
			discount = calcDiscount(totalPrice, member);
		
			priceForTax = totalPrice;
		
			tax = calcTax();
		
			condDiscount =  bookCondCalc(bookCond[custBookID], totalPrice);
		
			output(totalPrice, discount, tax, condDiscount, name);
	
		
			
		}
		else
		{
			cout<<"\nThe Program Has Stopped !";
		}
		
		cout<<"\n\nDO YOU WANT TO REPEAT THIS PROGRAM? ";
		cout<<"\npress 1 to repeat : ";
		cin>>repeatprogram;
		
	}

	return 0;
}

double input()
{
	cout<<"\n\nPlease insert book ID : ";
	cin>>custBookID;
	
	cout<<"\nYou Have choose Book ";
	cout<<title[custBookID];
	
	cout<<"\nPrice : RM";
	cout<<bookPrice[custBookID];
	
	cout<<"\nBook Conditions : ";
	cout<<bookCond[custBookID];
	
	return bookPrice[custBookID];
}

double calcDiscount(double price, char member)
{
	double totalDiscount = 0.0, discountPrice = 0.0, discountMember = 0.0;
	
	if(price >= 50)
	{
		discountPrice =  0.10 * price;	
		
		if(member == 'Y')
		{
			discountMember = 0.15 * price;
		}
		
		totalDiscount = discountPrice + discountMember;
	}
	else
	{
		if(member == 'Y')
		{
			discountMember = 0.15 * price;
		}	
		
		totalDiscount = discountMember;
			
	}	
	return totalDiscount;
}

double calcTax()
{
	double tax = 0;
	
	tax = 0.06 * priceForTax;
	
	return tax;	
}

double bookCondCalc(string cond, double price)
{
	double condPrice = 0;
	if(cond == "Used")
	{
		condPrice = 0.20 * price;
	}	
	else
	{
		condPrice = 0;
	}
	
	return condPrice;
}

void customerReceipt()
{
	cout<<"\n======================";
	cout<<"\nCustomer's Receipt";
	cout<<"\n======================";	
}

void output(double price, double discount, double tax, double condDiscount, string buyerName)
{
	double totalPrice = ( price - discount - condDiscount ) + tax;
	string title[13];
	
	customerReceipt();
	
	cout<<"\nCustomer name is: ";
	cout<<buyerName;
	cout<<"\nTotal Book Price : RM";
	cout<<price;
	cout<<"\nDiscount : RM";
	cout<<discount;
	cout<<"\nDiscount for book condition : RM";
	cout<<condDiscount;
	cout<<"\nTax : RM";
	cout<<tax;
	
	cout<<"\n\n---------------------";
	cout<<"\nTotal Price :  RM";
	cout<<totalPrice;
	cout<<"\n---------------------";
}

